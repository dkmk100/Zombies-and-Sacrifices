﻿static var lives : int = 2;
static var cooldown : int = 100;
static var maxlives : int = 6;
static var win : boolean = false;
function Update (){
if(cooldown<100){
cooldown+=1;
}
if(lives > maxlives){
lives=maxlives;
}
}
function OnGUI () {
	GUI.contentColor = Color.black;
	GUI.Label (Rect (210,10,150,50), ("Your lives left: "+lives+"/"+maxlives));
	if(lives<=0&&win==false){
	GUI.contentColor = Color.red;
	GUI.Label (Rect (650,300,300,300), ("Game Over!!!"));
	}
	if(win){
	GUI.contentColor = Color.green;
	GUI.Label (Rect (650,300,300,300), ("Victory!!"));
	}
}