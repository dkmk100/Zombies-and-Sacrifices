﻿static var necromancy : boolean = false;
static var betternecromancy : boolean = false;
function OnGUI () {
	GUI.contentColor = Color.black;
	if(necromancy){
	if(betternecromancy){
	GUI.Label (Rect (410,10,150,50), ("You can do the advanced necromancy spell!!"));
	}
	if (betternecromancy==false) {
	GUI.Label (Rect (410,10,150,50), ("You can do the necromancy spell!!"));
	}
	}

}