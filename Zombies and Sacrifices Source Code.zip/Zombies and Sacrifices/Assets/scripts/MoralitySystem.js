﻿static var morality : int = 0;
static var friend1 : boolean = true;//frenchie
static var friend2 : boolean = true;
static var friend3 : boolean = true;
static var friend4 : boolean = true;
var Friend1 : GameObject;
var Friend2 : GameObject;
var Friend3 : GameObject;
var Friend4 : GameObject;
var Collider1 : Collider;
var Collider2 : Collider;
var Collider3 : Collider;
var Collider4 : Collider;
function OnGUI () {
	GUI.contentColor = Color.black;
	GUI.Label (Rect (10,10,150,50), ("Your morality is at: "+morality));
	if(morality>=100){
	GUI.Label (Rect (10,20,100,50), ("you are a very good person!"));
	}
	else if(morality>=10){
	GUI.Label (Rect (10,20,100,50), ("you are a good person!"));
	}
	if(morality<=-100){
	GUI.Label (Rect (10,20,100,50), ("you are a very bad person!"));
	}
	else if(morality<=-10){
	GUI.Label (Rect (10,20,100,50), ("you are a bad person!"));
	}
}
function Update (){
Collider1 = Friend1.GetComponent(Collider);
Collider2 = Friend2.GetComponent(Collider);
Collider3 = Friend3.GetComponent(Collider);
Collider4 = Friend4.GetComponent(Collider);
	if (Input.GetKey("right")&&friend1)
        {
	morality -=25;   
	friend1=false;
	Collider1.enabled=false;
	Friend1.transform.Translate(new Vector3(0,-5,0));
	LifeSystem.lives+=1;
        }
        if (Input.GetKey("left")&&friend2)
        {
	morality -=25;   
	friend2=false;
	Collider2.enabled=false;
	Friend2.transform.Translate(new Vector3(0,-5,0));
	LifeSystem.lives+=1;
        }
        if (Input.GetKey("up")&&friend3)
        {
	morality -=25;   
	friend3=false;
	Collider3.enabled=false;
	Friend3.transform.Translate(new Vector3(0,-5,0));
	LifeSystem.lives+=1;
        }
        if (Input.GetKey("down")&&friend4)
        {
	morality -=25;   
	friend4=false;
	Collider4.enabled=false;
	Friend4.transform.Translate(new Vector3(0,-5,0));
	LifeSystem.lives+=1;
        }
        if(MagicSystem.necromancy&&LifeSystem.lives>0&&LifeSystem.maxlives>1){
        if (Input.GetKey("l")&&friend1==false&&LifeSystem.lives>0)
        {
	morality +=25;   
	friend1=true;
	Friend1.transform.Translate(new Vector3(0,5,0));
		Collider1.enabled=true;
		LifeSystem.lives-=1;
		if(MagicSystem.betternecromancy==false){
		LifeSystem.maxlives-=1;
		}
        }
        if (Input.GetKey("j")&&friend2==false&&LifeSystem.lives>0)
        {
	morality +=25;   
	friend2=true;
	Friend2.transform.Translate(new Vector3(0,5,0));
		Collider2.enabled=true;
		LifeSystem.lives-=1;
		if(MagicSystem.betternecromancy==false){
		LifeSystem.maxlives-=1;
		}
        }
        if (Input.GetKey("i")&&friend3==false&&LifeSystem.lives>0)
        {
	morality +=25;   
	friend3=true;
	Friend3.transform.Translate(new Vector3(0,5,0));
	Collider3.enabled=true;
	LifeSystem.lives-=1;
	if(MagicSystem.betternecromancy==false){
		LifeSystem.maxlives-=1;
		}
        }
        if (Input.GetKey("k")&&friend4==false&&LifeSystem.lives>0)
        {
	morality +=25;   
	friend4=true;
	Friend4.transform.Translate(new Vector3(0,5,0));
		Collider4.enabled=true;
		LifeSystem.lives-=1;
		if(MagicSystem.betternecromancy==false){
		LifeSystem.maxlives-=1;
		}
        }
        }
}
