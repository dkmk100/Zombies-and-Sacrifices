﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {
	public float thrust;
	public Rigidbody rb;
	void Start()
	{
		rb = GetComponent<Rigidbody>();
	}

	void FixedUpdate()
	{
		transform.rotation = Quaternion.identity;
		if (Input.GetKey("w")) {
			rb.AddForce (transform.forward * thrust);
		}
		if (Input.GetKey("s")) {
			rb.AddForce (transform.forward * thrust * -1);
		}
		if (Input.GetKey("d")) {
			rb.AddForce (transform.right * thrust);
		}
		if (Input.GetKey("a")) {
			rb.AddForce (transform.right * thrust * -1);
		}
	}
}