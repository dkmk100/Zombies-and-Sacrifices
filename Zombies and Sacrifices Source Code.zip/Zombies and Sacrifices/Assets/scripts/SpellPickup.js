﻿var spell : String;
function OnCollisionEnter (col : Collision) {
		if (col.gameObject.tag == "Player") {
if(spell == "necromancy"){
MagicSystem.necromancy=true;
Destroy(gameObject);
}
if(spell == "betternecromancy"){
MagicSystem.betternecromancy=true;
Destroy(gameObject);
}
}
}