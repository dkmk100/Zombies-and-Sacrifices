﻿function OnCollisionEnter (col : Collision) {
		if (col.gameObject.tag == "Player") {
Destroy(gameObject);
}
}