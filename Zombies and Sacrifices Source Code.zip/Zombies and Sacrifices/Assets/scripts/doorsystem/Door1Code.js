﻿function Update () {
	if (DoorSystem.door1==false)
		 {
         Destroy(gameObject);
         }
}