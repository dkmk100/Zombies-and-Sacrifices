﻿function Update () {
	if (DoorSystem.door2==false)
		 {
         Destroy(gameObject);
         }
}