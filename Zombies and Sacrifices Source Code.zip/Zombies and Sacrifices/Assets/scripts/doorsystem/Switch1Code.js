﻿function OnCollisionEnter (col : Collision) {
			DoorSystem.door1 = false;
			Destroy(gameObject);
}