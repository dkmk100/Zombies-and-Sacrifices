﻿function OnCollisionEnter (col : Collision) {
			DoorSystem.door3 = false;
			Destroy(gameObject);
}