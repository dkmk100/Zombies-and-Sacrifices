﻿function OnCollisionEnter (col : Collision) {
			DoorSystem.door4 = false;
			Destroy(gameObject);
}