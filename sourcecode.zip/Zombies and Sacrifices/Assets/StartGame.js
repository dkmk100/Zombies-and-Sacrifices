﻿import UnityEngine.SceneManagement;

function Update () {
	if (Input.GetKey ("space")) {
	SceneManager.LoadScene("GameBasic");
	}
}