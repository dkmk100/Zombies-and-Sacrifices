﻿function Update () {
if (MoralitySystem.friend1==false)
		 {
		 Destroy(gameObject);
         }
}