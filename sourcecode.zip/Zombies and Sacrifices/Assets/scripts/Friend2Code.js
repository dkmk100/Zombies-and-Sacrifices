﻿function Update () {
if (MoralitySystem.friend2==false)
		 {
         Destroy(gameObject);
         }
}
