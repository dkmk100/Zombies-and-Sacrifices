﻿function Update () {
if (MoralitySystem.friend3==false)
		 {
         Destroy(gameObject);
         }
}
function OnCollisionEnter (col : Collision) {
	if(col.gameObject.name == "Zombie1"){
		Destroy(gameObject);
	}
}