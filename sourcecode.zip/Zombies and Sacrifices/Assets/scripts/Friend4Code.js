﻿function Update () {
if (MoralitySystem.friend4==false)
		 {
         Destroy(gameObject);
         }
}
function OnCollisionEnter (col : Collision) {
	if(col.gameObject.name == "Zombie1"){
		Destroy(gameObject);
	}
}