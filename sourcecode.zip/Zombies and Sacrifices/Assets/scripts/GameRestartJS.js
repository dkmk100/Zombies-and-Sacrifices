﻿import UnityEngine.SceneManagement;
var source : AudioSource;
static var restarttimer : int = 50;
static var started : boolean = false;
function Start () {
source = GetComponent(AudioSource);
}
function Update () {
if(started) {
restarttimer -=1;
}
	if (Input.GetKey ("space")) {
			source.Play();
	        started=true;
		}
if(restarttimer<=0){
	        LifeSystem.lives=2;
			LifeSystem.maxlives=6;
			LifeSystem.cooldown=100;
			LifeSystem.win=false;
			LifeSystem.lose=false;
			LifeSystem.lifeshards=0;
			LifeSystem.maxlifeshards=0;
			MoralitySystem.morality=0;
			MoralitySystem.friend1=true;
			MoralitySystem.friend2=true;
			MoralitySystem.friend3=true;
			MoralitySystem.friend4=true;
			MagicSystem.necromancy=false;
			MagicSystem.betternecromancy=false;
			MagicSystem.autoheal=false;
			MagicSystem.automaxheal=false;
			DoorSystem.door1=true;
			DoorSystem.door2=true;
			DoorSystem.door3=true;
			DoorSystem.door4=true;
			DoorSystem.door5=true;
			DoorSystem.door6=true;
			DoorSystem.door7=true;
			DoorSystem.door8=true;
			DoorSystem.door9=true;
			DoorSystem.door10=true;
			started=false;
	        restarttimer=50;
			SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
			}
}