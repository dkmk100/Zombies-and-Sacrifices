﻿static var lives : int = 2;
static var cooldown : int = 100;
static var maxlives : int = 6;
static var win : boolean = false;
static var lose : boolean = false;
static var lifeshards : int = 0;
static var maxlifeshards : int = 0;
function Update (){
if(cooldown<100){
cooldown+=1;
}
if(lives > maxlives){
lives=maxlives;
}
if(lives <=0&&win==false){
lose=true;
}
if(lifeshards>=500){
lifeshards-=500;
lives+=1;
}
if(maxlifeshards>=2500){
maxlifeshards-=2500;
maxlives+=1;
}
}
function OnGUI () {
	GUI.contentColor = Color.black;
	GUI.Label (Rect (210,10,150,50), ("Your lives left: "+lives+"/"+maxlives));
	if(lose){
	GUI.contentColor = Color.red;
	GUI.Label (Rect (650,300,300,300), ("Game Over!!!"));
	GUI.Label (Rect (650,400,300,300), ("Push Spacebar to restart"));
	}
	if(win){
	GUI.contentColor = Color.green;
	GUI.Label (Rect (650,300,300,300), ("Victory!!"));
	}
}