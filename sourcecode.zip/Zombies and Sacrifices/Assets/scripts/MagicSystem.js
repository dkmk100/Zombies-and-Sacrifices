﻿static var necromancy : boolean = false;
static var betternecromancy : boolean = false;
static var autoheal : boolean = false;
static var automaxheal : boolean = false;
function OnGUI () {
	GUI.contentColor = Color.black;
	if(necromancy){
	if(betternecromancy){
	GUI.Label (Rect (410,10,150,50), ("You can do the advanced necromancy spell!!"));
	}
	if (betternecromancy==false) {
	GUI.Label (Rect (410,10,150,50), ("You can do the necromancy spell!!"));
	}
	}
	if (autoheal) {
	if (automaxheal) {
	GUI.Label (Rect (410,40,150,50), ("You can advanced self heal!!"));
	}
	else {
	GUI.Label (Rect (410,40,150,50), ("You can self heal!!"));
	}
	}
}

function Update () {
if(autoheal){
LifeSystem.lifeshards+=1;
}
if(automaxheal){
LifeSystem.maxlifeshards+=1;
autoheal=true;
}
}