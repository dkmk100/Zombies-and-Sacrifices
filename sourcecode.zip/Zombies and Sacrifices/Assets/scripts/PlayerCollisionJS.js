﻿var source : AudioSource;
function Start () {
source = GetComponent(AudioSource);
}
function OnCollisionEnter (col : Collision) {
		if (col.gameObject.tag == "enemy"&&LifeSystem.cooldown>=100) {
			LifeSystem.lives-=1;
			LifeSystem.cooldown=0;
			source.Play();
		}
}