﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour {
	public float thrust;
	public Rigidbody rb;
	public GameObject gameobject;
	public float maxspeed;
	void Start()
	{
		rb = GetComponent<Rigidbody>();
	}

	void FixedUpdate()
	{
		rb.constraints = (RigidbodyConstraints.FreezeRotation | RigidbodyConstraints.FreezePositionY);
		if (rb.velocity.x > maxspeed) {
			rb.velocity = new Vector3 (maxspeed, rb.velocity.y, rb.velocity.z);
		}
		if (rb.velocity.x < -maxspeed) {
			rb.velocity = new Vector3 (-maxspeed, rb.velocity.y, rb.velocity.z);
		}
		if (rb.velocity.z > maxspeed) {
			rb.velocity = new Vector3 (rb.velocity.x, rb.velocity.y, maxspeed);
		}
		if (rb.velocity.z < -maxspeed) {
			rb.velocity = new Vector3 (rb.velocity.x, rb.velocity.y, -maxspeed);
		}
		if (Input.GetKey("w")) {
			rb.AddForce (transform.forward * thrust);
		}
		if (Input.GetKey("s")) {
			rb.AddForce (transform.forward * thrust * -1);
		}
		if (Input.GetKey("d")) {
			rb.AddForce (transform.right * thrust);
		}
		if (Input.GetKey("a")) {
			rb.AddForce (transform.right * thrust * -1);
		}
	}
}