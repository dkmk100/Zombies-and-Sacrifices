﻿var thrust : float; 
var object : GameObject;
function Update () {
if (Input.GetKey("w")) {
			gameObject.Transform.translate(new Vector3 (0,0,1));
		}
		if (Input.GetKey("s")) {
		gameObject.Transform.translate(new Vector3 (0,0,-1));
		}
		if (Input.GetKey("d")) {
		gameObject.Transform.translate(new Vector3 (1,0,0));
		}
		if (Input.GetKey("a")) {
		gameObject.Transform.translate(new Vector3 (-1,0,0));
		}
	}