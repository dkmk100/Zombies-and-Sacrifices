﻿var target : GameObject;
var rb : Rigidbody;
var thrust : float;
var object : GameObject;
var maxspeed : float;
function Update () {
	rb.constraints = (RigidbodyConstraints.FreezeRotation | RigidbodyConstraints.FreezePositionY);
		if (rb.velocity.x > maxspeed) {
			rb.velocity = new Vector3 (maxspeed, rb.velocity.y, rb.velocity.z);
		}
		if (rb.velocity.x < -maxspeed) {
			rb.velocity = new Vector3 (-maxspeed, rb.velocity.y, rb.velocity.z);
		}
		if (rb.velocity.z > maxspeed) {
			rb.velocity = new Vector3 (rb.velocity.x, rb.velocity.y, maxspeed);
		}
		if (rb.velocity.z < -maxspeed) {
			rb.velocity = new Vector3 (rb.velocity.x, rb.velocity.y, -maxspeed);
		}
	if(object.transform.position.x>target.transform.position.x){
	rb.AddForce (object.transform.right * thrust * -1);
	}
	if(object.transform.position.x<target.transform.position.x){
	rb.AddForce (object.transform.right * thrust);
	}
	if(object.transform.position.z>target.transform.position.z){
	rb.AddForce (object.transform.forward * thrust * -1);
	}
	if(object.transform.position.z<target.transform.position.z){
	rb.AddForce (object.transform.forward * thrust);
	}
}
function OnCollisionEnter (col : Collision) {
if (col.gameObject.tag == "Player") {
object.transform.position = new Vector3 (0,1,0);
rb.velocity = new Vector3 (0,0,0);
}
}