﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetCodeC : MonoBehaviour {
	public float thrust;
	public Rigidbody rb;
	public GameObject gameobject;
	public GameObject target;
	void Start () {
		
	}

	void Update () {
		if(gameobject.transform.position.x>target.transform.position.x){
			rb.AddForce (gameobject.transform.right * thrust);
		}
		if(gameobject.transform.position.x<target.transform.position.x){
			rb.AddForce (gameobject.transform.right * thrust * -1);
		}
		if(gameobject.transform.position.z>target.transform.position.z){
			rb.AddForce (gameobject.transform.up * thrust);
		}
		if(gameobject.transform.position.z<target.transform.position.z){
			rb.AddForce (gameobject.transform.up * thrust * -1);
		}
	}
}
