﻿function OnCollisionEnter (col : Collision) {
		if (col.gameObject.tag == "Player") {
LifeSystem.win=true;
Destroy(gameObject);
}
}