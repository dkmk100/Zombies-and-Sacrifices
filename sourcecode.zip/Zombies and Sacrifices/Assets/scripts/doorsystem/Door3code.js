﻿function Update () {
	if (DoorSystem.door3==false)
		 {
         Destroy(gameObject);
         }
}