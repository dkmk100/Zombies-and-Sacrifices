﻿function Update () {
	if (DoorSystem.door4==false)
		 {
         Destroy(gameObject);
         }
}