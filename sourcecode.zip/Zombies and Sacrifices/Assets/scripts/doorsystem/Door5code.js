﻿function Update () {
	if (DoorSystem.door5==false)
		 {
         Destroy(gameObject);
         }
}