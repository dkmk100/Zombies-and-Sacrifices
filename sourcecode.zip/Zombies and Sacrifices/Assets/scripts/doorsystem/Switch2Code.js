﻿function OnCollisionEnter (col : Collision) {
			DoorSystem.door2 = false;
			Destroy(gameObject);
}