﻿function OnCollisionEnter (col : Collision) {
			DoorSystem.door5 = false;
			Destroy(gameObject);
}